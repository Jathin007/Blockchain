var TodoList = artifacts.require("./TodoList.sol");

module.exports = function(deployer) {
  deployer.deploy(TodoList);
};
/* Since we are running smart contracts on the blockchain,
the state or schema of the blockchain(database) is changed.
That is why we need these migrations. */